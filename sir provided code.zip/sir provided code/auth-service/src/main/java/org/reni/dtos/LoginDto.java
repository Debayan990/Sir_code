package org.reni.dtos;

public record LoginDto(String usernameOrEmail, String password) {
}
